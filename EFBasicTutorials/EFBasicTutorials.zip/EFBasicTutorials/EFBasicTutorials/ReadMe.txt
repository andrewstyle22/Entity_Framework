﻿Instruction to run this demo tutorials:
- Attach SchoolDB.mdf in your local MS SQL Server 2012
- If you have MS SQL Server 2008 or 2008 R2 then execute respective scripts included in the project: SchoolDBScript-MSSQL2008.sql or SchoolDBScript-MSSQL2008R2.sql
- Verify connection string in App.config and make sure that it is pointing to correct server & database. 
- You may delete School.exmx and add new one after creating SchoolDB database in your local server.